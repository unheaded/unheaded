# eBPF Foundation Implementation Plan

**Milestone:** 1.1 eBPF Foundation
**Status:** BLOCKED - Rust toolchain required
**Owner:** Architect + Muck
**ETA:** Jan 31, 2026

---

## 🚧 CURRENT BLOCKER

**Issue:** Rust/Aya toolchain not available in current environment
**Impact:** Cannot compile eBPF programs
**Resolution:** Need bare metal/VM with:
- Linux kernel 5.8+ with eBPF support
- Rust 1.70+ with cargo
- LLVM/Clang for BPF target compilation
- Root/sudo access for loading eBPF programs

**Environment Options:**
1. AWS EC2 (recommended: t3.medium with Ubuntu 22.04 LTS)
2. Local bare metal with Linux
3. VMware/QEMU with kernel 5.8+
4. Azure VM
5. Oracle Cloud

---

## 📋 WHAT WE'RE BUILDING

### Three eBPF Programs (Rust + Aya framework)

#### 1. packet_marker.bpf.rs
**Purpose:** Inject trace_id into packets at XDP layer
**Hook Type:** XDP (eXpress Data Path)
**Attach Point:** Network interface (host level)

**Responsibilities:**
- Generate unique trace_id for new flows
- Inject trace_id into packet metadata (not payload!)
- Use eBPF maps to track flow → trace_id mapping
- Forward packet to kernel stack (XDP_PASS)

**Key Data Structures:**
```rust
// Flow identification (5-tuple)
struct FlowKey {
    src_ip: u32,      // IPv4 source
    dst_ip: u32,      // IPv4 destination
    src_port: u16,
    dst_port: u16,
    protocol: u8,     // TCP/UDP
}

// Trace metadata
struct TraceMetadata {
    trace_id: u128,   // UUID
    first_seen: u64,  // timestamp
    packet_count: u64,
}

// eBPF map: FlowKey → TraceMetadata
HashMap<FlowKey, TraceMetadata>
```

**Algorithm:**
1. Parse packet headers (Ethernet → IP → TCP/UDP)
2. Extract 5-tuple (src_ip, dst_ip, src_port, dst_port, protocol)
3. Lookup flow in map
4. If new flow: generate trace_id, insert into map
5. If existing: increment packet_count
6. Write event to ring buffer for trace-collector
7. Return XDP_PASS (let packet continue)

**Event Format (to ring buffer):**
```rust
struct PacketEvent {
    trace_id: u128,
    timestamp: u64,
    src_ip: u32,
    dst_ip: u32,
    src_port: u16,
    dst_port: u16,
    protocol: u8,
    packet_size: u32,
    direction: u8,  // 0 = ingress, 1 = egress
}
```

#### 2. flow_tracker.bpf.rs
**Purpose:** Track connection state (TCP handshakes, teardowns)
**Hook Type:** kprobe
**Attach Point:** tcp_v4_connect, tcp_close, etc.

**Responsibilities:**
- Track TCP connection lifecycle
- Correlate with trace_id from packet_marker
- Detect connection state: SYN, ESTABLISHED, FIN, RST
- Measure connection duration
- Write flow events to ring buffer

**Key Data Structures:**
```rust
struct FlowState {
    trace_id: u128,
    state: u8,         // 0=NEW, 1=ESTABLISHED, 2=CLOSED
    start_time: u64,
    end_time: u64,
    bytes_sent: u64,
    bytes_recv: u64,
}
```

**Events:**
- `FLOW_START`: New connection detected
- `FLOW_ESTABLISHED`: TCP handshake complete
- `FLOW_CLOSE`: Connection terminated
- `FLOW_RESET`: Connection reset (RST)

#### 3. latency_probe.bpf.rs
**Purpose:** Measure round-trip time (RTT) for packets
**Hook Type:** kprobe + kretprobe
**Attach Point:** Network stack functions (e.g., ip_output, tcp_v4_rcv)

**Responsibilities:**
- Timestamp outgoing packets
- Match with incoming responses
- Calculate RTT
- Track per-flow latency statistics
- Detect slow paths

**Key Data Structures:**
```rust
struct LatencyEvent {
    trace_id: u128,
    rtt_us: u64,       // microseconds
    timestamp: u64,
}

struct LatencyStats {
    min_rtt: u64,
    max_rtt: u64,
    avg_rtt: u64,
    p50_rtt: u64,
    p95_rtt: u64,
    p99_rtt: u64,
}
```

**Measurement Strategy:**
- Store timestamp when packet leaves (kprobe on ip_output)
- Retrieve timestamp when response arrives (kprobe on tcp_v4_rcv)
- Calculate delta
- Use eBPF map with timestamp cleanup (TTL)

---

## 🔧 TRACE-COLLECTOR SERVICE (Rust)

**Location:** `cmd/trace-collector/src/main.rs`
**Purpose:** Read eBPF ring buffers, publish to Busboy

### Architecture

```
┌──────────────────────┐
│ eBPF Ring Buffers    │
│ - packet_marker      │
│ - flow_tracker       │
│ - latency_probe      │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ trace-collector      │
│ (Rust userspace)     │
│                      │
│ • Poll ring buffers  │
│ • Correlate events   │
│ • Enrich metadata    │
│ • Batch publish      │
└──────────┬───────────┘
           │ gRPC
           ▼
┌──────────────────────┐
│ Busboy               │
│ Topic:               │
│ network.traces       │
└──────────────────────┘
```

### Implementation

```rust
use aya::{Bpf, programs::Xdp, maps::perf::AsyncPerfEventArray};
use tokio::task;

#[tokio::main]
async fn main() -> Result<()> {
    // Load eBPF programs
    let mut bpf = Bpf::load_file("packet_marker.bpf.o")?;
    let program: &mut Xdp = bpf.program_mut("packet_marker").unwrap().try_into()?;
    program.load()?;
    program.attach("eth0", XdpFlags::default())?;

    // Open ring buffer
    let mut perf_array = AsyncPerfEventArray::try_from(bpf.map_mut("events")?)?;

    // Connect to Busboy
    let busboy_client = BusboyClient::connect("10.10.10.10:9090").await?;

    // Poll ring buffer
    for cpu_id in online_cpus()? {
        let mut buf = perf_array.open(cpu_id, None)?;

        task::spawn(async move {
            let mut buffers = (0..10)
                .map(|_| BytesMut::with_capacity(1024))
                .collect::<Vec<_>>();

            loop {
                let events = buf.read_events(&mut buffers).await.unwrap();

                for buf in buffers.iter_mut().take(events.read) {
                    let event = parse_packet_event(buf);

                    // Publish to Busboy
                    let trace_msg = NetworkTrace {
                        trace_id: event.trace_id,
                        timestamp: event.timestamp,
                        src_ip: event.src_ip,
                        dst_ip: event.dst_ip,
                        // ... more fields
                    };

                    busboy_client.publish("network.traces", &trace_msg).await?;
                }
            }
        });
    }

    // Keep running
    tokio::signal::ctrl_c().await?;
    Ok(())
}
```

### Dependencies (Cargo.toml)

```toml
[dependencies]
aya = { version = "0.12", features = ["async_tokio"] }
aya-log = "0.2"
tokio = { version = "1", features = ["full"] }
tonic = "0.11"  # gRPC client
prost = "0.12"  # Protobuf
anyhow = "1.0"
log = "0.4"
env_logger = "0.11"
```

---

## 🔨 BUILD PROCESS

### Prerequisites

```bash
# Install Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install BPF target
rustup target add bpfel-unknown-none

# Install bpf-linker
cargo install bpf-linker

# Install LLVM
sudo apt install llvm clang
```

### Compile eBPF Programs

```bash
cd ebpf

# Build each eBPF program
cargo build --release --target bpfel-unknown-none

# Outputs:
# target/bpfel-unknown-none/release/packet_marker
# target/bpfel-unknown-none/release/flow_tracker
# target/bpfel-unknown-none/release/latency_probe
```

### Compile trace-collector

```bash
cd cmd/trace-collector

# Build userspace program
cargo build --release

# Output:
# target/release/trace-collector
```

---

## 🧪 TESTING STRATEGY

### Unit Testing (per eBPF program)

Use `aya-test` framework:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_flow_key_parsing() {
        // Test packet header parsing
    }

    #[test]
    fn test_trace_id_generation() {
        // Test UUID generation logic
    }

    #[test]
    fn test_xdp_pass_decision() {
        // Test that XDP_PASS is returned
    }
}
```

### Integration Testing

1. **VM with test traffic:**
```bash
# Terminal 1: Start trace-collector
sudo ./target/release/trace-collector

# Terminal 2: Generate test traffic
ping 10.10.10.10
curl http://10.10.10.10:8080/health

# Terminal 3: Subscribe to Busboy
./busboy-cli subscribe network.traces

# Verify: Events appear in Busboy subscription
```

2. **Verify trace_id correlation:**
- Send HTTP request
- Check packet_marker assigns trace_id
- Check flow_tracker tracks connection
- Check latency_probe measures RTT
- Verify all events share same trace_id

### Performance Testing

```bash
# Benchmark eBPF overhead
sudo bpftool prog profile <prog_id>

# Target: < 10 microseconds per packet
# Acceptable: < 50 microseconds
# Unacceptable: > 100 microseconds
```

### Load Testing

```bash
# Generate high packet rate
iperf3 -c 10.10.10.10 -t 60 -P 10

# Monitor:
# - CPU usage (should be < 20%)
# - Packet drop rate (should be 0%)
# - Ring buffer overruns (should be 0)
```

---

## 📊 SUCCESS CRITERIA

- [ ] packet_marker.bpf compiles without errors
- [ ] flow_tracker.bpf compiles without errors
- [ ] latency_probe.bpf compiles without errors
- [ ] trace-collector compiles and starts
- [ ] eBPF programs load successfully
- [ ] trace_id injected into packets
- [ ] Events appear in Busboy topic `network.traces`
- [ ] Trace correlation works (same trace_id across events)
- [ ] No packet drops under normal load
- [ ] Latency overhead < 50 microseconds
- [ ] Clean unload (no kernel panics!)

---

## 🚨 RISK MITIGATION

### Risk 1: Kernel Version Compatibility
**Mitigation:** Test on Ubuntu 22.04 LTS (kernel 5.15) which is well-supported

### Risk 2: eBPF Verifier Rejection
**Mitigation:** Start simple, add complexity incrementally, use aya-log for debugging

### Risk 3: Ring Buffer Overflow
**Mitigation:** Use per-CPU ring buffers, implement backpressure, monitor overruns

### Risk 4: Packet Drop / Performance Impact
**Mitigation:** Benchmark early, use XDP_PASS (not XDP_TX), minimize map lookups

### Risk 5: Privilege Escalation / Security
**Mitigation:** Load via unheaded-daemon (controlled), no customer packet payload access

---

## 📚 REFERENCES

- [Aya Book](https://aya-rs.dev/book/)
- [eBPF Documentation](https://ebpf.io/what-is-ebpf/)
- [XDP Tutorial](https://github.com/xdp-project/xdp-tutorial)
- [Linux Observability with BPF](https://www.oreilly.com/library/view/linux-observability-with/9781492050193/)

---

## 🎯 NEXT ACTIONS (When Environment Ready)

1. **Set up bare metal/VM** with kernel 5.8+, Rust, root access
2. **Install Aya toolchain** and dependencies
3. **Implement packet_marker.bpf.rs** (start with minimal XDP_PASS)
4. **Test packet_marker** in isolation (ping test)
5. **Implement flow_tracker.bpf.rs**
6. **Implement latency_probe.bpf.rs**
7. **Implement trace-collector** userspace service
8. **Integration test** all three programs together
9. **Performance benchmark** and tune
10. **Integrate with Busboy** and test end-to-end

---

**STATUS:** Implementation plan COMPLETE. Blocked on Rust/eBPF environment.
**Unblocks:** Control Plane (Milestone 1.2)
**Timeline impact:** None if environment ready by Jan 28.

**Let's ship this when we have metal.** 🚀
