# Kanban Dashboard - Busboy Integration Refactor

**Date:** 2026-01-26
**Current State:** Backend exists (timeguru proxy), no frontend
**Target State:** Busboy-native real-time Kanban with frontend

---

## The Situation

### What EXISTS:
1. **cmd/kanban-app/main.go** (262 LOC)
   - HTTP server with health/ready/metrics
   - WebSocket support
   - Timeline proxy to timeguru service (OLD ARCHITECTURE)
   - Static file serving
   - No Busboy integration

2. **Busboy Client Library** (pkg/busboy-client/)
   - Full gRPC client ✅
   - 7 message types including TaskAssignment, TimelineUpdate ✅
   - Pub/sub ready ✅

### What's MISSING:
1. **Busboy integration** in kanban-app backend
2. **Frontend** (HTML/JS/CSS)
3. **Message subscriptions** to topics
4. **In-memory task board** state

---

## Architecture Comparison

### OLD (Current kanban-app):
```
Browser → kanban-app:8001 → timeguru:8000 → timeline.md
           (HTTP proxy)      (REST API)
```

### NEW (Busboy-native):
```
Services → Busboy → kanban-app → Browser
(publish)  (topics) (subscribe)  (WebSocket)

Topics:
- timeline.updates (timeguru)
- tasks.assignments (micromanager)
- strategy.decisions (captain)
- design.proposals (architect)
```

---

## Refactor Strategy

### Option A: Keep Existing + Add Busboy (HYBRID)
**Pros:**
- Backward compatible with timeguru
- Gradual migration
- Fallback to polling if Busboy down

**Cons:**
- More complex
- Two data sources
- More code to maintain

### Option B: Replace with Pure Busboy (CLEAN SLATE) ← **RECOMMENDED**
**Pros:**
- Clean architecture
- Single source of truth (Busboy)
- Demonstrates message bus properly
- Simpler code

**Cons:**
- Breaking change from existing design
- Requires services to publish

---

## Implementation Plan (Option B - Recommended)

### Phase 1: Backend Refactor (2-4 hours)

**File:** `cmd/kanban-app-v2/main.go` (NEW - don't break existing)

```go
package main

import (
    busboyClient "github.com/unheaded/unheaded/pkg/busboy-client"
    // ... other imports
)

// In-memory task board state
type TaskBoard struct {
    sync.RWMutex
    Tasks map[string]*Task
}

type Task struct {
    ID          string
    Title       string
    Description string
    Status      string  // "backlog", "in_progress", "review", "done"
    Assignee    string  // service name
    Phase       string
    Progress    int     // 0-100
    UpdatedAt   time.Time
    TraceID     string
}

func main() {
    // Initialize task board
    board := &TaskBoard{
        Tasks: make(map[string]*Task),
    }

    // Connect to Busboy
    client, err := busboyClient.NewClient("busboy:9090")
    if err != nil {
        log.Fatal(err)
    }
    defer client.Close()

    ctx := context.Background()
    if err := client.Connect(ctx); err != nil {
        log.Fatal(err)
    }

    // Subscribe to all relevant topics
    go subscribeToTopics(ctx, client, board)

    // Start HTTP server (WebSocket + REST API)
    startHTTPServer(board)
}

func subscribeToTopics(ctx context.Context, client *busboyClient.Client, board *TaskBoard) {
    // Timeline updates
    client.Subscribe(ctx, busboyClient.TopicTimelineUpdates, func(topic string, data []byte) error {
        return handleTimelineUpdate(data, board)
    })

    // Task assignments
    client.Subscribe(ctx, busboyClient.TopicTasksAssignments, func(topic string, data []byte) error {
        return handleTaskAssignment(data, board)
    })

    // Strategy decisions (create high-level tasks)
    client.Subscribe(ctx, busboyClient.TopicStrategyDecisions, func(topic string, data []byte) error {
        return handleStrategyDecision(data, board)
    })

    // Design proposals (create design tasks)
    client.Subscribe(ctx, busboyClient.TopicDesignProposals, func(topic string, data []byte) error {
        return handleDesignProposal(data, board)
    })
}

func handleTaskAssignment(data []byte, board *TaskBoard) error {
    var msg busboyClient.TaskAssignment
    if err := json.Unmarshal(data, &msg); err != nil {
        return err
    }

    board.Lock()
    defer board.Unlock()

    board.Tasks[msg.TaskID] = &Task{
        ID:          msg.TaskID,
        Title:       msg.TaskTitle,
        Description: msg.Description,
        Status:      msg.Status,
        Assignee:    msg.AssignedTo,
        Phase:       msg.Phase,
        Progress:    msg.Progress,
        UpdatedAt:   time.Now(),
        TraceID:     msg.TraceID,
    }

    // Broadcast to WebSocket clients
    broadcastTaskUpdate(board.Tasks[msg.TaskID])

    return nil
}

// ... similar handlers for other message types
```

**Key Changes:**
1. Import Busboy client library
2. Connect to Busboy instead of proxying timeguru
3. Subscribe to 4 topic types
4. Maintain in-memory task board
5. Update board on message receive
6. Broadcast to WebSocket clients

**Endpoints:**
- `GET /health` - Health check
- `GET /ready` - Ready when Busboy connected
- `GET /metrics` - Prometheus metrics
- `GET /api/v1/tasks` - Get all tasks (NEW)
- `GET /api/v1/tasks/:status` - Get tasks by status (NEW)
- `WS /ws` - WebSocket for real-time updates
- `GET /` - Serve frontend static files

### Phase 2: Frontend Implementation (2-4 hours)

**Files:**
- `cmd/kanban-app-v2/static/index.html`
- `cmd/kanban-app-v2/static/app.js`
- `cmd/kanban-app-v2/static/styles.css`

**index.html:**
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unheaded Kanban - The Meta Moment</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <canvas id="particle-canvas"></canvas>

    <header>
        <h1>Unheaded Kanban</h1>
        <div class="live-indicator" id="live-indicator">
            <span class="dot"></span>
            <span>LIVE</span>
        </div>
    </header>

    <main class="kanban-board">
        <div class="column" id="backlog">
            <h2>Backlog</h2>
            <div class="cards"></div>
        </div>

        <div class="column" id="in_progress">
            <h2>In Progress</h2>
            <div class="cards"></div>
        </div>

        <div class="column" id="review">
            <h2>Review</h2>
            <div class="cards"></div>
        </div>

        <div class="column" id="done">
            <h2>Done</h2>
            <div class="cards"></div>
        </div>
    </main>

    <script src="particles.js"></script>
    <script src="app.js"></script>
</body>
</html>
```

**app.js:**
```javascript
// WebSocket connection
let ws = null;
let reconnectTimeout = null;

// Task state
const tasks = new Map();

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    fetchInitialTasks();
    connectWebSocket();
    startParticles();
});

// Fetch initial task list via REST
async function fetchInitialTasks() {
    try {
        const response = await fetch('/api/v1/tasks');
        const data = await response.json();

        data.tasks.forEach(task => {
            tasks.set(task.id, task);
        });

        renderBoard();
    } catch (err) {
        console.error('Failed to fetch tasks:', err);
    }
}

// WebSocket for real-time updates
function connectWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${protocol}//${window.location.host}/ws`);

    ws.onopen = () => {
        console.log('WebSocket connected');
        document.getElementById('live-indicator').classList.add('active');
    };

    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);

        if (data.type === 'task_update') {
            tasks.set(data.task.id, data.task);
            updateTaskCard(data.task);
        }
    };

    ws.onclose = () => {
        console.log('WebSocket disconnected');
        document.getElementById('live-indicator').classList.remove('active');

        // Reconnect after 5 seconds
        reconnectTimeout = setTimeout(connectWebSocket, 5000);
    };

    ws.onerror = (err) => {
        console.error('WebSocket error:', err);
    };
}

// Render entire board
function renderBoard() {
    // Clear all columns
    document.querySelectorAll('.cards').forEach(col => col.innerHTML = '');

    // Group tasks by status
    tasks.forEach(task => {
        createTaskCard(task);
    });
}

// Create task card element
function createTaskCard(task) {
    const card = document.createElement('div');
    card.className = 'task-card';
    card.dataset.id = task.id;

    card.innerHTML = `
        <div class="card-header">
            <h3>${task.title}</h3>
            <span class="assignee">${task.assignee}</span>
        </div>
        <p class="description">${task.description || ''}</p>
        ${task.progress > 0 ? `
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${task.progress}%"></div>
            </div>
            <div class="progress-text">${task.progress}%</div>
        ` : ''}
        <div class="card-footer">
            <span class="status-badge status-${task.status}">${task.status.replace('_', ' ')}</span>
            <span class="phase">${task.phase}</span>
        </div>
    `;

    // Append to correct column
    const column = document.querySelector(`#${task.status} .cards`);
    if (column) {
        column.appendChild(card);
    }
}

// Update single task card
function updateTaskCard(task) {
    const existingCard = document.querySelector(`[data-id="${task.id}"]`);

    if (existingCard) {
        // Remove old card
        existingCard.remove();
    }

    // Create new card in correct column
    createTaskCard(task);
}

// Particle background (simple version)
function startParticles() {
    const canvas = document.getElementById('particle-canvas');
    const ctx = canvas.getContext('2d');

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.5,
            vy: (Math.random() - 0.5) * 0.5,
            size: Math.random() * 2 + 1,
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;

            // Wrap around edges
            if (p.x < 0) p.x = canvas.width;
            if (p.x > canvas.width) p.x = 0;
            if (p.y < 0) p.y = canvas.height;
            if (p.y > canvas.height) p.y = 0;

            // Draw particle
            ctx.fillStyle = 'rgba(74, 158, 255, 0.5)';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        });

        requestAnimationFrame(animate);
    }

    animate();

    // Resize handler
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}
```

**styles.css:**
```css
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Space Grotesk', -apple-system, system-ui, sans-serif;
    background: #0a0a0a;
    color: #e0e0e0;
    overflow-x: hidden;
}

#particle-canvas {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 0;
    pointer-events: none;
}

header {
    position: relative;
    z-index: 10;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 2rem 4rem;
    border-bottom: 1px solid #222;
}

h1 {
    font-size: 2rem;
    font-weight: 700;
    letter-spacing: -0.02em;
}

.live-indicator {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #888;
    font-size: 0.875rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
}

.live-indicator .dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #555;
}

.live-indicator.active .dot {
    background: #22c55e;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.kanban-board {
    position: relative;
    z-index: 10;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2rem;
    padding: 2rem 4rem;
    max-width: 1800px;
    margin: 0 auto;
}

.column {
    background: rgba(21, 21, 21, 0.8);
    border-radius: 12px;
    padding: 1.5rem;
    min-height: 500px;
}

.column h2 {
    font-size: 1.125rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #4a9eff;
}

.cards {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.task-card {
    background: #1a1a1a;
    border: 1px solid #2a2a2a;
    border-radius: 8px;
    padding: 1rem;
    transition: all 0.2s;
}

.task-card:hover {
    transform: translateY(-2px);
    border-color: #4a9eff;
    box-shadow: 0 4px 12px rgba(74, 158, 255, 0.2);
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 0.75rem;
}

.card-header h3 {
    font-size: 1rem;
    font-weight: 600;
    line-height: 1.4;
    flex: 1;
}

.assignee {
    font-size: 0.75rem;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-left: 0.5rem;
}

.description {
    font-size: 0.875rem;
    color: #aaa;
    line-height: 1.5;
    margin-bottom: 1rem;
}

.progress-bar {
    width: 100%;
    height: 6px;
    background: #2a2a2a;
    border-radius: 3px;
    overflow: hidden;
    margin-bottom: 0.5rem;
}

.progress-fill {
    height: 100%;
    background: #4a9eff;
    transition: width 0.3s;
}

.progress-text {
    font-size: 0.75rem;
    color: #888;
    margin-bottom: 0.75rem;
}

.card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 0.5rem;
}

.status-badge {
    font-size: 0.75rem;
    padding: 0.25rem 0.75rem;
    border-radius: 12px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    font-weight: 600;
}

.status-backlog {
    background: #2a2a2a;
    color: #888;
}

.status-in_progress {
    background: rgba(245, 158, 11, 0.2);
    color: #f59e0b;
}

.status-review {
    background: rgba(74, 158, 255, 0.2);
    color: #4a9eff;
}

.status-done {
    background: rgba(34, 197, 94, 0.2);
    color: #22c55e;
}

.phase {
    font-size: 0.75rem;
    color: #666;
}

@media (max-width: 1400px) {
    .kanban-board {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .kanban-board {
        grid-template-columns: 1fr;
    }

    header {
        padding: 1.5rem 2rem;
    }

    .kanban-board {
        padding: 1.5rem 2rem;
    }
}
```

### Phase 3: Testing (1-2 hours)

**Test Scenarios:**

1. **Backend Standalone:**
```bash
# Start Busboy
docker run -p 9090:9090 unheaded/busboy:latest

# Start kanban-app-v2
cd cmd/kanban-app-v2
BUSBOY_ADDR=localhost:9090 go run main.go

# Check health
curl http://localhost:8001/health
curl http://localhost:8001/ready

# Publish test message (using busboy CLI or test script)
# Verify task appears in /api/v1/tasks
```

2. **WebSocket Real-time:**
```javascript
// Browser console
const ws = new WebSocket('ws://localhost:8001/ws');
ws.onmessage = (e) => console.log(JSON.parse(e.data));

// Publish task update via Busboy
// Verify WebSocket receives message
// Verify UI updates
```

3. **Full Integration:**
```bash
# Start full stack:
# - Busboy
# - kanban-app-v2
# - timeguru (integrated with Busboy)
# - micromanager (integrated with Busboy)

# Open browser: http://localhost:8001
# Verify:
#   - Particles animating
#   - Live indicator pulsing
#   - Tasks displayed
#   - Real-time updates when services publish
```

---

## Success Criteria

- [ ] Backend connects to Busboy successfully
- [ ] Backend subscribes to 4 topics
- [ ] In-memory task board updates on messages
- [ ] WebSocket broadcasts to connected clients
- [ ] Frontend displays 4-column Kanban board
- [ ] Task cards show all fields (title, status, assignee, progress)
- [ ] Real-time updates work (publish → WebSocket → UI update)
- [ ] Particle background animates smoothly
- [ ] Live indicator reflects WebSocket status
- [ ] Health/ready/metrics endpoints work
- [ ] Can demo: manually publish → see on board instantly

---

## File Structure

```
cmd/kanban-app-v2/
├── main.go              (NEW - Busboy-native backend)
├── handlers.go          (HTTP/WebSocket handlers)
├── board.go             (In-memory task board)
├── static/
│   ├── index.html       (NEW - Frontend)
│   ├── app.js           (NEW - WebSocket client + rendering)
│   ├── particles.js     (NEW - Background animation)
│   └── styles.css       (NEW - Dark theme)
├── Dockerfile
├── README.md
└── go.mod
```

---

## Dependencies

**Go:**
```go
require (
    github.com/gorilla/websocket v1.5.1
    github.com/rs/zerolog v1.31.0
    github.com/google/uuid v1.6.0
    google.golang.org/grpc v1.60.1
)
```

**JavaScript:**
- No external dependencies (Vanilla JS)

---

## Timeline

| Phase | Estimated Time | Status |
|-------|---------------|--------|
| Backend refactor | 2-4 hours | Not started |
| Frontend implementation | 2-4 hours | Not started |
| Integration testing | 1-2 hours | Not started |
| **Total** | **5-10 hours** | **Ready to start** |

---

## Next Steps

1. **Create cmd/kanban-app-v2/** directory
2. **Implement main.go** with Busboy integration
3. **Create static/** directory with frontend files
4. **Test with Busboy** running locally
5. **Demo** the dogfooding moment

---

**LET'S BUILD THE REAL-TIME KANBAN DASHBOARD!** 🚀
