# Performance Optimizations Reference — UPC Computermancer

## Table of Contents
1. Scanline Batching Implementation
2. Inline Hot Opcode Switch
3. LOCAL Mode CRC Skip
4. CLMUL CRC Acceleration
5. Anamnesis Sampling
6. I/O Region Bitmask
7. Double-Buffer Framebuffer Strategy
8. BSP Cache-Friendly Layout
9. Instruction Pipeline Stall Analysis
10. Memory Hierarchy Tuning
11. Benchmarking Methodology

---

## 1. Scanline Batching Implementation

### Problem
Per-pixel `bpf_wotan_write()` = 64,000 helper calls/frame at 320×200.
Each helper call: context switch overhead + map lookup + memcpy + return.
Measured: ~100-200ns per helper call = 6.4-12.8ms/frame JUST for writes.
At 35fps budget of 28.5ms/frame, that's 22-45% of frame time on writes alone.

### Solution
Accumulate pixels in BPF stack/per-cpu buffer, flush per scanline.

```rust
// In Shim eBPF program (Rust/aya)
const SCREEN_WIDTH: u32 = 320;
const FRAMEBUF_BASE: u32 = 0x0000; // data memory, NOT I/O region

// Per-scanline buffer on BPF stack (512 bytes max stack, 320 fits)
let mut scanline: [u8; 320] = [0u8; 320];
let mut scanline_x: u32 = 0;
let mut current_y: u32 = 0;

// Inside MBC STORE handler:
fn handle_store_framebuf(addr: u32, value: u8) {
    let pixel_offset = addr - FRAMEBUF_BASE;
    let y = pixel_offset / SCREEN_WIDTH;
    let x = pixel_offset % SCREEN_WIDTH;

    if y != current_y && scanline_x > 0 {
        // Flush previous scanline
        let write_addr = FRAMEBUF_BASE + (current_y * SCREEN_WIDTH);
        unsafe {
            bpf_wotan_write(flow_label, write_addr, scanline.as_ptr(), SCREEN_WIDTH);
        }
        scanline_x = 0;
        current_y = y;
    }

    scanline[x as usize] = value;
    scanline_x = x + 1;
}

// End of frame: flush last scanline + trigger I/O
fn flush_frame() {
    // Flush remaining scanline
    if scanline_x > 0 {
        let write_addr = FRAMEBUF_BASE + (current_y * SCREEN_WIDTH);
        unsafe {
            bpf_wotan_write(flow_label, write_addr, scanline.as_ptr(), SCREEN_WIDTH);
        }
    }
    // Write trigger byte to I/O region = "frame ready"
    let trigger: u8 = 1;
    unsafe {
        bpf_wotan_write(flow_label, 0xC000, &trigger as *const u8, 1);
    }
}
```

### Result
- 200 helper calls/frame (one per scanline) + 1 trigger = 201 total
- Down from 64,000. **~318x reduction.**
- Write overhead: 201 × 200ns = ~40μs/frame (was 6.4-12.8ms)

### BPF Stack Limitation
BPF stack is 512 bytes. Scanline of 320 bytes fits.
If resolution increases beyond 512 pixels wide, use per-cpu array map instead.

---

## 2. Inline Hot Opcode Switch

### Problem
Every MBC instruction decoded via Sophia BPF map lookup.
Map lookup: bpf_map_lookup_elem() = ~100-200ns.
At ~100K instructions/frame: 10-20ms in decode alone.

### Solution
Hardcode top opcodes directly in Shim. Sophia lookup only for 0x14+.

```rust
// In Shim execution loop
fn execute_instruction(opcode: u8, rd: u8, rs: u8, imm: u16) -> Result<(), i32> {
    match opcode {
        // === INLINE HOT (no Sophia lookup) ===
        0x00 => { /* NOP */ }
        0x01 => { regs[rd] = regs[rs]; }                              // MOV
        0x02 => { regs[rd] = regs[rd].wrapping_add(regs[rs]); update_flags(); } // ADD
        0x03 => { regs[rd] = regs[rd].wrapping_sub(regs[rs]); update_flags(); } // SUB
        0x04 => { regs[rd] = regs[rd] & regs[rs]; update_flags(); }   // AND
        0x05 => { regs[rd] = regs[rd] | regs[rs]; update_flags(); }   // OR
        0x06 => { regs[rd] = regs[rd] ^ regs[rs]; update_flags(); }   // XOR
        0x07 => { regs[rd] = !regs[rd]; update_flags(); }             // NOT
        0x08 => { regs[rd] = regs[rd] << (rs & 0x1F); update_flags(); } // SHL
        0x09 => { regs[rd] = regs[rd] >> (rs & 0x1F); update_flags(); } // SHR
        0x0A => {                                                       // CMP
            let result = regs[rd].wrapping_sub(regs[rs]);
            flags.zero = result == 0;
            flags.carry = regs[rd] < regs[rs];
            flags.sign = (result as i32) < 0;
        }
        0x0B => { pc = imm as u32; }                                   // JMP
        0x0C => { if flags.zero { pc = imm as u32; } }                // JZ
        0x0D => { if !flags.zero { pc = imm as u32; } }               // JNZ
        0x0E => {                                                       // LOAD
            let mut buf = [0u8; 4];
            unsafe { bpf_wotan_read(flow_label, imm as u32, buf.as_mut_ptr(), 4); }
            regs[rd] = u32::from_le_bytes(buf);
        }
        0x0F => {                                                       // STORE
            let buf = regs[rs].to_le_bytes();
            let addr = imm as u32;
            if (addr >> 14) == 3 {
                // I/O region — trigger screen write path
                handle_store_framebuf(addr, buf[0]);
            } else {
                unsafe { bpf_wotan_write(flow_label, addr, buf.as_ptr(), 4); }
            }
        }
        0x10 => {                                                       // CALL
            push_stack(pc + 1);
            pc = imm as u32;
        }
        0x11 => { pc = pop_stack(); }                                   // RET
        0x12 => { push_stack(regs[rs]); }                              // PUSH
        0x13 => { regs[rd] = pop_stack(); }                            // POP

        // === SOPHIA LOOKUP (extended opcodes) ===
        _ => {
            let key = opcode as u32;
            let handler = unsafe { bpf_map_lookup_elem(&SOPHIA_DICT, &key) };
            match handler {
                Some(h) => execute_extended(h, rd, rs, imm),
                None => return Err(-EINVAL),
            }
        }
    }
    Ok(())
}
```

### Result
- Opcodes 0x00-0x13 (20 instructions): ~20-50ns each (pure computation, no map lookup)
- These cover ~95% of Doom's instruction mix
- 5% extended opcodes still hit Sophia: ~150ns each
- Weighted average: ~25-60ns/instruction (was 100-200ns)
- **3-8x decode speedup**

---

## 3. LOCAL Mode CRC Skip

### Problem
CRC-16 CCITT computed on every 20-byte Monad. ~50-100ns per CRC.
In LOCAL mode, packets never hit wire. CRC protects against bit flips in transit.
No transit = no bit flips = CRC is waste.

### Solution
Flag bit in Monad header: `TRUSTED_LOCAL` (bit 7 of flags byte, offset 11).

```rust
const FLAG_TRUSTED_LOCAL: u8 = 0x80;

fn process_monad(monad: &[u8; 20]) -> Result<Monad, Error> {
    let flags = monad[11];

    // One AND + branch-not-taken in LOCAL mode
    if (flags & FLAG_TRUSTED_LOCAL) == 0 {
        // DISTRIBUTED mode: verify CRC
        let stored_crc = u16::from_be_bytes([monad[18], monad[19]]);
        let computed_crc = crc16_ccitt(&monad[..18]);
        if stored_crc != computed_crc {
            return Err(Error::BadChecksum);
        }
    }
    // else: LOCAL mode, skip CRC entirely

    parse_fields(monad)
}
```

### Security Note
TRUSTED_LOCAL must ONLY be set for same-host flows. Shield XDP must strip this flag on any packet arriving from network interface. BlackMage should fuzz this.

---

## 4. CLMUL CRC Acceleration

For DISTRIBUTED mode where CRC is mandatory.

```rust
// x86_64 with PCLMULQDQ (available since Westmere, 2010)
#[cfg(target_arch = "x86_64")]
fn crc16_ccitt_fast(data: &[u8]) -> u16 {
    // NOTE: This is the userspace helper version.
    // In BPF context, use bpf_crc16() helper if available,
    // or fall back to table lookup.

    // CLMUL-based CRC processes 16 bytes at a time
    // For 18-byte Monad payload: one 16-byte CLMUL + 2-byte tail
    // ~5-10ns vs ~50-100ns for byte-at-a-time table lookup
    unsafe {
        // ... architecture-specific intrinsics
        _mm_clmulepi64_si128(/* ... */)
    }
}

// Fallback for non-x86 or BPF context
fn crc16_ccitt_table(data: &[u8]) -> u16 {
    let mut crc: u16 = 0xFFFF;
    for &byte in data {
        let idx = ((crc >> 8) ^ (byte as u16)) & 0xFF;
        crc = (crc << 8) ^ CRC_TABLE[idx as usize];
    }
    crc
}
```

---

## 5. Anamnesis Sampling

```rust
// In Shim event emission
static mut FRAME_COUNT: u32 = 0;

fn maybe_emit_anamnesis(event_type: u8, monad_before: &[u8; 20], monad_after: &[u8; 20]) {
    unsafe { FRAME_COUNT = FRAME_COUNT.wrapping_add(1); }

    // Sample mask: 0x1F = every 32nd frame, 0x0F = every 16th, 0x00 = every frame
    const SAMPLE_MASK: u32 = 0x1F;

    if (unsafe { FRAME_COUNT } & SAMPLE_MASK) != 0 {
        return; // Skip — one AND + one branch
    }

    // Emit event (only runs ~1/32 of the time)
    let event = AnamnesisEvent {
        timestamp_ns: unsafe { bpf_ktime_get_ns() },
        event_type,
        // ... fill remaining fields
    };
    unsafe { bpf_ringbuf_output(&ANAMNESIS_RING, &event, 64, 0); }
}
```

### Result
At 35fps: ~1 event/sec instead of 35 events/sec (with mask 0x1F).
Configurable: tighter mask for debugging, wider for production.

---

## 6. I/O Region Bitmask

```rust
// SLOW: two comparisons + AND
fn is_io_region_slow(addr: u32) -> bool {
    addr >= 0xC000 && addr <= 0xFFFE
}

// FAST: one shift + one comparison
fn is_io_region_fast(addr: u32) -> bool {
    (addr >> 14) == 3  // 0xC000 >> 14 = 3, 0xFFFF >> 14 = 3
}

// EDGE CASE: 0xFFFF is input register, not framebuffer
// So actual I/O write region is 0xC000-0xFFFE
fn is_io_write_region(addr: u32) -> bool {
    (addr >> 14) == 3 && addr != 0xFFFF
}
// Still faster: branch predictor will almost always predict addr != 0xFFFF as true
```

---

## 7. Double-Buffer Framebuffer Strategy

### Memory Layout

```
DATA MEMORY (0x0000-0xBFFF = 48KB):
  0x0000-0x7FFF: Program data, stack, heap (32KB)
  0x8000-0x9F3F: Framebuffer A (320×200×1 = 62.5KB... PROBLEM)

ISSUE: 320×200 at 8bpp = 64,000 bytes. Even one framebuffer doesn't fit in 48KB data region.

SOLUTIONS:
A) Use 4bpp (16 colors) = 32,000 bytes. Fits. Doom used 256 colors though.
B) Use extended memory (0x10000+) for framebuffers. Wotan supports 16MB extended.
C) Reduce resolution: 256×160 = 40,960 bytes at 8bpp. Fits in data memory.
D) Column-major tile rendering with partial flushes.

RECOMMENDED: Option B — extended memory framebuffers.
```

### Extended Memory Double Buffer

```
EXTENDED MEMORY (0x10000-0xFFFFFF):
  0x10000-0x1F9FF: Framebuffer A (64,000 bytes)
  0x20000-0x2F9FF: Framebuffer B (64,000 bytes)
  0x30000+:        WAD data, BSP tree, textures

FLOW:
  1. Game renders to Framebuffer A
  2. Frame complete → atomic swap: active = B, display = A
  3. Write 0xC000 = buffer_id (0 or 1) → triggers Busboy publish
  4. Busboy subscriber reads from display buffer address
  5. Game starts rendering to Framebuffer B
  6. Repeat

SWAP MECHANISM:
  Single Wotan CAS (compare-and-swap) on address 0x0000 (buffer pointer):
    bpf_wotan_cas(flow, 0x0000, expected=0x10000, desired=0x20000)
  Atomic. Lock-free. One helper call per frame.
```

---

## 8. BSP Cache-Friendly Layout

### Problem
Doom's BSP tree is pointer-chasing: node → left child → right child → ... 
Each node access = Wotan read helper call.
Random access pattern = poor cache locality in Wotan L1.

### Solution: Van Emde Boas Layout

Pack BSP nodes in memory order that matches traversal order.
Van Emde Boas layout clusters parent and children together in memory.

```
Standard layout (breadth-first):
  Node 0 at offset 0
  Node 1 at offset 64
  Node 2 at offset 128
  ... (children far from parents in deep trees)

Van Emde Boas layout:
  Recursively cluster subtrees together.
  Parent and both children within same 64-byte L1 cache line when possible.
  Result: ~2-3x fewer cache misses during traversal.
```

### Node Packing

```rust
// Pack BSP node to exactly 64 bytes (= Wotan L1 cache line)
#[repr(C, packed)]
struct BSPNode {
    partition_x: i16,     // 2
    partition_y: i16,     // 4
    delta_x: i16,         // 6
    delta_y: i16,         // 8
    right_bbox: [i16; 4], // 16
    left_bbox: [i16; 4],  // 24
    right_child: u16,     // 26 (index, not pointer — saves 2 bytes)
    left_child: u16,      // 28
    sector_id: u16,       // 30
    flags: u16,           // 32
    _padding: [u8; 32],   // 64 (pad to cache line, or pack extra data)
}
// Exactly 64 bytes. One Wotan L1 read per node. No straddling.
```

---

## 9. Instruction Pipeline Stall Analysis

### Stall Sources

| Stall Type | Cause | Mitigation |
|------------|-------|------------|
| Memory stall | Wotan read/write latency | Batch writes, prefetch |
| Decode stall | Sophia map lookup | Inline hot opcodes |
| Branch stall | JZ/JNZ misprediction | Profile branch patterns |
| I/O stall | Busboy publish latency | Async fire-and-forget |
| Interrupt stall | (future) timer interrupt | Minimize ISR work |

### Ideal Pipeline Utilization

```
Target: 100K instructions/frame at 35fps = 3.5M instructions/sec
At 200ns/instruction: 0.7 seconds of compute per second of wall time
At 50ns/instruction (with optimizations): 0.175 sec compute per sec wall
Headroom: 82.5% of CPU time available for OS overhead, etc.
```

---

## 10. Memory Hierarchy Tuning

### Current Hierarchy

```
L0: Monad (20 bytes, ~370ns/hop)         — register file in transit
L1: BPF map cache (64-byte lines, ~100-200ns) — per-hop fast storage
L2: Ring buffer (configurable, ~1-10μs)   — per-flow RAM
L3: WAL (disk, ~100μs-1ms)               — persistent
L4: Sophia dicts (BPF maps, ~100-200ns)  — instruction decode
```

### Optimization: Separate Code and Data Caches

Currently L1 serves both instruction fetch and data access.
For Doom, instruction working set is small but data (BSP, textures) is large.

**Proposed**: Two BPF maps for L1:
- `L1_CODE`: LRU hash map, 4KB, for instruction fetch (Sophia hot opcodes live here)
- `L1_DATA`: LRU hash map, 16KB, for data reads (BSP nodes, textures)

Prevents instruction fetches from evicting data cache entries and vice versa.
Harvard-ish architecture at the cache level. Von Neumann at the memory level.

---

## 11. Benchmarking Methodology

### Microbenchmarks

```bash
# Per-instruction timing
BPF_PROG=shim_compute perf stat -e cycles,instructions,cache-misses \
  -- bpftool prog run pinned /sys/fs/bpf/shim_compute repeat 10000

# Wotan helper call latency
bpftool prog profile id $PROG_ID duration 5 \
  | grep -E 'wotan_(read|write|cas)'

# Sophia lookup latency
bpftool map dump id $SOPHIA_MAP_ID | wc -l  # entry count
# Then time 10K lookups via test program
```

### Macrobenchmarks (Doom-specific)

```
1. Frame time: bpf_ktime_get_ns() at frame start/end
2. Instruction count: counter incremented per execute_instruction()
3. Helper call count: counter per bpf_wotan_{read,write,cas}()
4. Cache hit/miss: counter in L1 map lookup wrapper
5. Event emission rate: Anamnesis ring buffer consumer counter

Target metrics:
  Frame time:     < 28.5ms (35fps)
  Instructions:   < 150K/frame
  Helper calls:   < 500/frame (with batching)
  Cache hit rate:  > 90%
  Event rate:      < 2/sec (with sampling)
```

---

*SPDX-License-Identifier: GPL-3.0-or-later*
*The Computermancer measures before optimizing. Always.*
